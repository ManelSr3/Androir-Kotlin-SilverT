package com.manel.silvertour

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.Adapter
import android.widget.ArrayAdapter
import android.widget.BaseAdapter


class CustomAdapter: BaseAdapter
{
    val sections: Map<String, Adapter> = LinkedHashMap<String, Adapter>()
    var headers: ArrayAdapter<String>? = null

    constructor (context: Context) {
        this.headers = ArrayAdapter(context, R.layout.list_header)
    }

    fun addSection(section: String?, adapter: Adapter?) {
        headers!!.add(section)
        sections.plus(pair = Pair(section,adapter))
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View? {
        var sectionnum = 0
        var positionAux = position

        for (section in sections.keys) {
            val adapter = sections[section]
            val size = adapter!!.count + 1

            if (positionAux === 0) return headers!!.getView(sectionnum, convertView, parent)
            if (positionAux < size) return adapter.getView(positionAux - 1, convertView, parent)

            positionAux -= size
            sectionnum++
        }
        return null
    }

    override fun getItem(position: Int): Any? {

        var positionAux = position

        for (section in sections.keys) {
            val adapter = sections[section]
            val size = adapter!!.count + 1

            // check if position inside this section
            if (positionAux === 0) return section
            if (positionAux < size) return adapter.getItem(positionAux - 1)

            // otherwise jump into next section
            positionAux -= size
        }
        return null

    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getCount(): Int {
        var total = 0
        for (adapter in sections.values) total += adapter.count + 1
        return total
    }
}