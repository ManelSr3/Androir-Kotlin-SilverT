package com.manel.silvertour

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView.OnItemClickListener
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    var sections = arrayOf("Cash", "Credit Card", "Bank account")
    var categories = arrayOf("Tax", "Grocery", "Entertaiment", "Gym", "Health")

    private var listView: ListView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(toolbar)

        var adapter = CustomAdapter(this)
        val listadapter = ArrayAdapter(this, R.layout.list_item, categories)

        for (i in 0 until sections.size) {
            adapter.addSection(sections[i], listadapter)
        }

        listView = findViewById<View>(R.id.list_journal) as ListView
        listView!!.adapter = adapter;
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        return when (item.itemId) {
            R.id.action_settings -> {
                this.startActivity(Intent(this, AddActivity::class.java))
                return true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
