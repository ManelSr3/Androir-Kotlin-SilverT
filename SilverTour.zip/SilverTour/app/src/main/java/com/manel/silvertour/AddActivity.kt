package com.manel.silvertour

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import kotlinx.android.synthetic.main.activity_add.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.toolbar
import org.w3c.dom.Text

class AddActivity : AppCompatActivity() {

    var sections = arrayOf("Cash", "Credit Card", "Bank account")
    var categories = arrayOf("Tax", "Grocery", "Entertaiment", "Gym", "Health")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)
        setSupportActionBar(toolbar)
        (supportActionBar)!!.setDisplayHomeAsUpEnabled(true)

        val toggleButton = findViewById<ToggleButton>(R.id.toggleButton2)
        val sectionsSpn = findViewById<Spinner>(R.id.spinner)
        val categoriesSpn = findViewById<Spinner>(R.id.spinner2)
        val save = findViewById<Button>(R.id.button)
        val amount = findViewById<EditText>(R.id.editText)

        if (sectionsSpn != null) {
            val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, sections)
            sectionsSpn.adapter = adapter

            sectionsSpn.onItemSelectedListener = object :
                AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                }

                override fun onNothingSelected(parent: AdapterView<*>) {
                    // write code to perform some action
                }
            }
        }

        if (categoriesSpn != null) {
            val adapter2 = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)
            categoriesSpn.adapter = adapter2
            categoriesSpn.onItemSelectedListener = object :
                AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                }

                override fun onNothingSelected(parent: AdapterView<*>) {
                    // write code to perform some action
                }
            }
        }

        if(save != null)
        {
            save.setOnClickListener { Toast.makeText(this@AddActivity, toggleButton.isChecked.toString() + " " + sectionsSpn.selectedItem + " " + categoriesSpn.selectedItem + " " + amount.text , Toast.LENGTH_SHORT).show() }
        }
    }
}
